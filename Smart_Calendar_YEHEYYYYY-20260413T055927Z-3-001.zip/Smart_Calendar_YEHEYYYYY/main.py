from abc import ABC, abstractmethod
import tkinter as tk
from tkinter import messagebox
import json
import os
import hashlib
from school_calendar import CalendarApp
from QuizReader_updated import QuizReader
from notifsys import NotificationSystem, User as NotifUser, Admin as NotifAdmin, NotificationApp

class LoginSystem:
    FILE_NAME = "users.json"

    def __init__(self):
        self.users = self.load_users()

    def hash_password(self, password):
        return hashlib.sha256(password.encode()).hexdigest()

    def load_users(self):
        if not os.path.exists(self.FILE_NAME):
            return {}
        with open(self.FILE_NAME, "r") as file:
            return json.load(file)

    def save_users(self, users):
        with open(self.FILE_NAME, "w") as file:
            json.dump(users, file, indent=4)

    def create_account(self, username, password, role):
        if username in self.users:
            return False, "Username already exists!"
        self.users[username] = {
            "password": self.hash_password(password),
            "role": role
        }
        self.save_users(self.users)
        return True, "Account created!"

    def login(self, username, password):
        if username in self.users and self.users[username]["password"] == self.hash_password(password):
            return True, self.users[username]["role"]
        return False, "Invalid login!"

class Person(ABC):
    def __init__(self, username):
        self._username = username  # Encapsulation: protected attribute

    @property
    def username(self):
        return self._username

    @abstractmethod
    def get_menu_options(self):
        # Abstraction: abstract method
        pass

    @abstractmethod
    def handle_option(self, option, main_app):
        # Abstraction: abstract method
        pass

class Student(Person):
    def get_menu_options(self):
        return ["Calendar", "Quiz"]

    def handle_option(self, option, main_app):
        if option == "Calendar":
            self.open_calendar(main_app)
        elif option == "Quiz":
            self.open_quiz(main_app)

    def open_calendar(self, main_app):
        cal_win = tk.Toplevel(main_app.root)
        cal_app = CalendarApp(cal_win)

    def open_quiz(self, main_app):
        quiz = QuizReader("Questions.txt", "Answers.txt")
        quiz.quiz_mode("Questions.txt", "Answers.txt")

class Admin(Person):
    def __init__(self, username):
        super().__init__(username)  # Inheritance
        self._notif_user = NotifUser(username)
        self._notif_admin = NotifAdmin(username)

    def get_menu_options(self):
        return ["Notifications", "Manage Users"]

    def handle_option(self, option, main_app):
        if option == "Notifications":
            self.open_notifications(main_app)
        elif option == "Manage Users":
            self.manage_users(main_app)

    def open_notifications(self, main_app):
        notif_win = tk.Toplevel(main_app.root)
        notif_app = NotificationApp(notif_win, main_app.notification_system, self._notif_user, self._notif_admin)

    def manage_users(self, main_app):
        users = main_app.login_system.users
        info = "\n".join([f"{u} ({d['role']})" for u, d in users.items()])
        messagebox.showinfo("Users", info or "No users")

class MainApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Main Application")
        self.login_system = LoginSystem()
        self.notification_system = NotificationSystem()
        self.current_user = None
        self.show_login()

    def show_login(self):
        self.clear()
        tk.Label(self.root, text="Login", font=("Arial", 16)).pack(pady=10)
        tk.Label(self.root, text="Username").pack()
        self.entry_username = tk.Entry(self.root)
        self.entry_username.pack()
        tk.Label(self.root, text="Password").pack()
        self.entry_password = tk.Entry(self.root, show="*")
        self.entry_password.pack()
        tk.Button(self.root, text="Login", command=self.login).pack(pady=5)
        tk.Button(self.root, text="Create Account", command=self.create_account_window).pack()

    def create_account_window(self):
        win = tk.Toplevel(self.root)
        win.title("Create Account")
        tk.Label(win, text="Username").pack()
        entry_user = tk.Entry(win)
        entry_user.pack()
        tk.Label(win, text="Password").pack()
        entry_pass = tk.Entry(win, show="*")
        entry_pass.pack()
        role_var = tk.StringVar(value="user")
        tk.Label(win, text="Role").pack()
        tk.Radiobutton(win, text="User", variable=role_var, value="user").pack()
        tk.Radiobutton(win, text="Admin", variable=role_var, value="admin").pack()
        def create():
            username = entry_user.get().strip()
            password = entry_pass.get().strip()
            role = role_var.get()
            success, msg = self.login_system.create_account(username, password, role)
            if success:
                messagebox.showinfo("Success", msg)
                win.destroy()
            else:
                messagebox.showerror("Error", msg)
        tk.Button(win, text="Create", command=create).pack()

    def login(self):
        username = self.entry_username.get().strip()
        password = self.entry_password.get().strip()
        success, role_or_msg = self.login_system.login(username, password)
        if success:
            role = role_or_msg
            if role == "user":
                self.current_user = Student(username)  # Polymorphism: different subclasses
            else:
                self.current_user = Admin(username)
            self.show_menu()
        else:
            messagebox.showerror("Error", role_or_msg)

    def show_menu(self):
        self.clear()
        tk.Label(self.root, text=f"Welcome {self.current_user.username}", font=("Arial", 16)).pack(pady=10)
        options = self.current_user.get_menu_options()
        for opt in options:
            tk.Button(self.root, text=opt, command=lambda o=opt: self.current_user.handle_option(o, self)).pack(pady=5)
        tk.Button(self.root, text="Logout", command=self.logout).pack(pady=5)

    def logout(self):
        self.current_user = None
        self.show_login()

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

if __name__ == "__main__":
    app = MainApp()
    app.root.mainloop()