import tkinter as tk
from tkinter import messagebox

# =========================
# DATA CLASSES
# =========================
class Announcement:
    def __init__(self, message, aid):
        self.message = message
        self.id = aid


class User:
    def __init__(self, username):
        self.username = username
        self.read = set()

    def mark_read(self, aid):
        self.read.add(aid)

    def unread_count(self, announcements):
        return len([a for a in announcements if a.id not in self.read])


class Admin:
    def __init__(self, username):
        self.username = username

    def create_announcement(self, system, message):
        system.add_announcement(message)


class NotificationSystem:
    def __init__(self):
        self.announcements = []
        self.next_id = 1

    def add_announcement(self, message):
        ann = Announcement(message, self.next_id)
        self.announcements.append(ann)
        self.next_id += 1
        self.popup(message)

    def popup(self, message):
        messagebox.showinfo("New Notification", message)


# =========================
# MAIN APP GUI
# =========================
class NotificationApp:
    def __init__(self, root, system, user, admin):
        self.root = root
        self.root.title("Notification System")

        self.system = system
        self.user = user
        self.admin = admin

        self.main_menu()

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    # =========================
    # LOGIN MENU
    # =========================
    def main_menu(self):
        self.clear()

        tk.Label(self.root, text="NOTIFICATIONS", font=("Arial", 16)).pack(pady=10)

        tk.Button(self.root, text="User View", width=20, command=self.user_menu).pack(pady=5)
        tk.Button(self.root, text="Admin View", width=20, command=self.admin_menu).pack(pady=5)
        tk.Button(self.root, text="Back", width=20, command=self.root.destroy).pack(pady=5)

    # =========================
    # USER MENU
    # =========================
    def user_menu(self):
        self.clear()

        unread = self.user.unread_count(self.system.announcements)

        tk.Label(self.root, text="USER MENU", font=("Arial", 16)).pack(pady=10)

        self.notif_btn = tk.Button(
            self.root,
            text=f"Notifications ({unread})",
            width=25,
            command=self.view_notifications
        )
        self.notif_btn.pack(pady=5)

        tk.Button(self.root, text="Back", width=25, command=self.main_menu).pack(pady=5)

    def refresh_user_menu(self):
        unread = self.user.unread_count(self.system.announcements)
        self.notif_btn.config(text=f"Notifications ({unread})")

    def view_notifications(self):
        self.clear()

        tk.Label(self.root, text="ANNOUNCEMENTS", font=("Arial", 16)).pack(pady=10)

        frame = tk.Frame(self.root)
        frame.pack()

        if not self.system.announcements:
            tk.Label(frame, text="No announcements available").pack()
        else:
            for ann in self.system.announcements:
                status = "READ" if ann.id in self.user.read else "UNREAD"

                row = tk.Frame(frame)
                row.pack(anchor="w", pady=2)

                tk.Label(row, text=f"[{ann.id}] {ann.message} ({status})").pack(side="left")

                if ann.id not in self.user.read:
                    tk.Button(
                        row,
                        text="Mark as Read",
                        command=lambda a=ann: self.mark_read(a)
                    ).pack(side="right")

        tk.Button(self.root, text="Back", command=self.user_menu).pack(pady=10)

    def mark_read(self, ann):
        self.user.mark_read(ann.id)
        self.view_notifications()

    # =========================
    # ADMIN MENU
    # =========================
    def admin_menu(self):
        self.clear()

        tk.Label(self.root, text="ADMIN MENU", font=("Arial", 16)).pack(pady=10)

        tk.Button(self.root, text="Create Announcement", width=25, command=self.create_announcement).pack(pady=5)
        tk.Button(self.root, text="View All Announcements", width=25, command=self.view_all).pack(pady=5)
        tk.Button(self.root, text="Back", width=25, command=self.main_menu).pack(pady=5)

    def create_announcement(self):
        self.clear()

        tk.Label(self.root, text="Create Announcement", font=("Arial", 16)).pack(pady=10)

        entry = tk.Entry(self.root, width=40)
        entry.pack(pady=5)

        def submit():
            msg = entry.get().strip()
            if msg:
                self.admin.create_announcement(self.system, msg)
                messagebox.showinfo("Success", "Announcement created!")
                self.admin_menu()
            else:
                messagebox.showwarning("Error", "Message cannot be empty.")

        tk.Button(self.root, text="Submit", command=submit).pack(pady=5)
        tk.Button(self.root, text="Back", command=self.admin_menu).pack(pady=5)

    def view_all(self):
        self.clear()

        tk.Label(self.root, text="ALL ANNOUNCEMENTS", font=("Arial", 16)).pack(pady=10)

        if not self.system.announcements:
            tk.Label(self.root, text="No announcements yet").pack()
        else:
            for ann in self.system.announcements:
                tk.Label(self.root, text=f"[{ann.id}] {ann.message}").pack(anchor="w")

        tk.Button(self.root, text="Back", command=self.admin_menu).pack(pady=10)