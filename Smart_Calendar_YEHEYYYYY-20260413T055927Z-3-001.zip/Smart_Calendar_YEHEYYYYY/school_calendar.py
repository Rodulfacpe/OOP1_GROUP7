import tkinter as tk
import calendar
import random
from datetime import datetime
from QuizReader_updated import QuizReader

class CalendarApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Calendar")

        # current date
        self.year = datetime.now().year
        self.month = datetime.now().month

        # generate random quiz days
        self.quiz_days = self.generate_quiz_days()

        # UI
        self.label = tk.Label(root, font=("Arial", 14))
        self.label.pack(pady=10)

        self.frame = tk.Frame(root)
        self.frame.pack()

        btn_frame = tk.Frame(root)
        btn_frame.pack(pady=10)

        tk.Button(root, text="Add Question", command=self.add_question).pack()
        tk.Button(root, text="Delete All", command=self.delete_all).pack()
        tk.Button(btn_frame, text="<<", command=self.prev_month).grid(row=0, column=0, padx=5)
        tk.Button(btn_frame, text=">>", command=self.next_month).grid(row=0, column=1, padx=5)

        # show calendar
        self.show_calendar()

    def generate_quiz_days(self):
        quiz_days = []
        cal = calendar.monthcalendar(self.year, self.month)

        for week in cal:
            for i, day in enumerate(week):
                if day != 0 and i < 5:  # weekdays only
                    if random.random() < 0.3:  # 30% chance
                        quiz_days.append((self.year, self.month, day))

        return quiz_days

    def show_calendar(self):
        for widget in self.frame.winfo_children():
            widget.destroy()

        self.label.config(text=f"{calendar.month_name[self.month]} {self.year}")

        cal = calendar.monthcalendar(self.year, self.month)

        for r, week in enumerate(cal):
            for c, day in enumerate(week):
                if day == 0:
                    tk.Label(self.frame, text="", width=5, height=2).grid(row=r, column=c)
                else:
                    if (self.year, self.month, day) in self.quiz_days:
                        tk.Button(
                            self.frame,
                            text=str(day) + "\nQUIZ",
                            bg="yellow",
                            width=5,
                            height=2,
                            command=self.start_quiz
                        ).grid(row=r, column=c)
                    else:
                        tk.Label(
                            self.frame,
                            text=str(day),
                            width=5,
                            height=2
                        ).grid(row=r, column=c)

    def start_quiz(self):
        quiz = QuizReader()
        quiz.quiz_mode("Questions.txt", "Answers.txt")

    def prev_month(self):
        self.month -= 1
        if self.month < 1:
            self.month = 12
            self.year -= 1

        self.quiz_days = self.generate_quiz_days()
        self.show_calendar()

    def next_month(self):
        self.month += 1
        if self.month > 12:
            self.month = 1
            self.year += 1

        self.quiz_days = self.generate_quiz_days()
        self.show_calendar()

    def start_quiz(self):
        quiz = QuizReader("Questions.txt", "Answers.txt")
        quiz.quiz_mode("Questions.txt", "Answers.txt")

    def add_question(self):
        quiz = QuizReader("Questions.txt", "Answers.txt")
        quiz.write_add_ques_ans("Questions.txt", "Answers.txt")

    def delete_all(self):
        quiz = QuizReader("Questions.txt", "Answers.txt")
        quiz.clear_all("Questions.txt", "Answers.txt")


if __name__ == "__main__":
    root = tk.Tk()
    app = CalendarApp(root)
    root.mainloop()