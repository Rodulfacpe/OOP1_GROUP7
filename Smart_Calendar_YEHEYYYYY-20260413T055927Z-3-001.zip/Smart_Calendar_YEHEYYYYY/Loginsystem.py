import tkinter as tk
from tkinter import messagebox
import json
import os
import hashlib

FILE_NAME = "users.json"

# ---------------- SECURITY ----------------
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# ---------------- FILE HANDLING ----------------
def load_users():
    if not os.path.exists(FILE_NAME):
        return {}
    with open(FILE_NAME, "r") as file:
        return json.load(file)

def save_users(users):
    with open(FILE_NAME, "w") as file:
        json.dump(users, file, indent=4)

users = load_users()

# ---------------- MAIN WINDOW ----------------
root = tk.Tk()
root.title("Secure Login System")
root.geometry("350x300")
root.configure(bg="#f5f5f5")

# ---------------- CREATE ACCOUNT ----------------
def create_account():
    def toggle_password():
        if show_pass.get():
            entry_pass.config(show="")
        else:
            entry_pass.config(show="*")

    def save_account():
        username = entry_user.get().strip()
        password = entry_pass.get().strip()
        role = role_var.get()

        if not username or not password:
            messagebox.showerror("Error", "Fields cannot be empty!")
            return

        if username in users:
            messagebox.showerror("Error", "Username already exists!")
            return

        users[username] = {
            "password": hash_password(password),
            "role": role
        }

        save_users(users)
        messagebox.showinfo("Success", "Account created!")
        create_win.destroy()

    create_win = tk.Toplevel(root)
    create_win.title("Create Account")
    create_win.geometry("350x300")
    create_win.configure(bg="#ffffff")

    tk.Label(create_win, text="Create Account", font=("Arial", 14, "bold")).pack(pady=10)

    tk.Label(create_win, text="Username").pack()
    entry_user = tk.Entry(create_win)
    entry_user.pack()

    tk.Label(create_win, text="Password").pack()
    entry_pass = tk.Entry(create_win, show="*")
    entry_pass.pack()

    show_pass = tk.BooleanVar()
    tk.Checkbutton(create_win, text="Show Password", variable=show_pass, command=toggle_password).pack()

    role_var = tk.StringVar(value="user")
    tk.Label(create_win, text="Role").pack()
    tk.Radiobutton(create_win, text="User", variable=role_var, value="user").pack()
    tk.Radiobutton(create_win, text="Admin", variable=role_var, value="admin").pack()

    tk.Button(create_win, text="Create", bg="#4CAF50", fg="white", command=save_account).pack(pady=10)

# ---------------- LOGIN ----------------
def login():
    username = entry_username.get().strip()
    password = hash_password(entry_password.get().strip())

    if username in users and users[username]["password"] == password:
        role = users[username]["role"]
        messagebox.showinfo("Success", f"Welcome {username}!")
        open_dashboard(username, role)
    else:
        messagebox.showerror("Error", "Invalid login!")

# ---------------- DASHBOARD ----------------
def open_dashboard(username, role):
    dash = tk.Toplevel(root)
    dash.title("Dashboard")
    dash.geometry("400x300")

    tk.Label(dash, text=f"Welcome, {username}", font=("Arial", 14, "bold")).pack(pady=10)

    if role == "admin":
        tk.Label(dash, text="Admin Panel", fg="red").pack()

        tk.Button(dash, text="View Users", command=view_users).pack(pady=5)
        tk.Button(dash, text="Delete User", command=delete_user).pack(pady=5)

    else:
        tk.Label(dash, text="User Panel", fg="blue").pack()

# ---------------- ADMIN FEATURES ----------------
def view_users():
    if not users:
        messagebox.showinfo("Users", "No users found.")
        return

    info = ""
    for user, data in users.items():
        info += f"{user} ({data['role']})\n"

    messagebox.showinfo("User List", info)

def delete_user():
    def confirm_delete():
        user_to_delete = entry_del.get().strip()

        if user_to_delete not in users:
            messagebox.showerror("Error", "User not found!")
            return

        del users[user_to_delete]
        save_users(users)
        messagebox.showinfo("Success", "User deleted!")
        del_win.destroy()

    del_win = tk.Toplevel(root)
    del_win.title("Delete User")
    del_win.geometry("300x150")

    tk.Label(del_win, text="Enter username to delete").pack(pady=10)
    entry_del = tk.Entry(del_win)
    entry_del.pack()

    tk.Button(del_win, text="Delete", bg="red", fg="white", command=confirm_delete).pack(pady=10)

# ---------------- MAIN UI ----------------
def toggle_main_password():
    if show_main_pass.get():
        entry_password.config(show="")
    else:
        entry_password.config(show="*")

tk.Label(root, text="Login", font=("Arial", 16, "bold"), bg="#f5f5f5").pack(pady=10)

tk.Label(root, text="Username", bg="#f5f5f5").pack()
entry_username = tk.Entry(root)
entry_username.pack()

tk.Label(root, text="Password", bg="#f5f5f5").pack()
entry_password = tk.Entry(root, show="*")
entry_password.pack()

show_main_pass = tk.BooleanVar()
tk.Checkbutton(root, text="Show Password", variable=show_main_pass,
               command=toggle_main_password, bg="#f5f5f5").pack()

tk.Button(root, text="Login", bg="#2196F3", fg="white", command=login).pack(pady=5)
tk.Button(root, text="Create Account", command=create_account).pack()

# RUN
root.mainloop()